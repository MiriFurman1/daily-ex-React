import React from 'react';
import Box2 from './Box2';

function Box1() {
  return (
    <div>
      Box1
      <Box2 />
    </div>
  );
}

export default Box1;
