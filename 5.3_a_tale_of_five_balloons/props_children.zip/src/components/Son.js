import React from 'react';
import GrandSon from './GrandSon';

function Son({ color }) {
  return <div>Son</div>;
}

export default Son;
