import React from 'react';

function GrandSon({ color }) {
  return <div>GrandSon </div>;
}

export default GrandSon;
