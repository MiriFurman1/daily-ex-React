import React from 'react';

function LargeHeading({ text }) {
  return <h1>{text}</h1>;
}

export default LargeHeading;
